# Analitica Ascensor  > 2025-11-20 8:25am
https://universe.roboflow.com/alico-sa/analitica-ascensor-9aese

Provided by a Roboflow user
License: CC BY 4.0

